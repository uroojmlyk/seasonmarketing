// import Link from "next/link";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faHouse } from "@fortawesome/free-solid-svg-icons";

// export default function Logo({ dark = true, className = "" }: { dark?: boolean; className?: string }) {
//   return (
//     <Link href="/" className={`group inline-flex items-center gap-3 ${className}`}>
      
//       {/* Bada Orange Icon (InvoiceTools style) */}
//       <FontAwesomeIcon 
//         icon={faHouse} 
//         className="h-10 w-10 shrink-0 text-brand-500" 
//       />
      
//       {/* Text: Season (White) + Marketing (Orange) */}
//       <span
//         className={`font-display text-2xl sm:text-[1.7rem] font-extrabold tracking-tight ${
//           dark ? "text-white" : "text-ink"
//         }`}
//       >
//         Season<span className="text-brand-500">Marketing</span>
//       </span>
//     </Link>
//   );
// }




import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHouse } from "@fortawesome/free-solid-svg-icons";

export default function Logo({
  dark = true,
  className = ""
}: {
  dark?: boolean;
  className?: string;
}) {
  return (
    <Link
      href="/"
      aria-label="Season Marketing home"
      className={`group inline-flex shrink-0 items-center gap-2 ${className}`}
    >
      <FontAwesomeIcon
        icon={faHouse}
        className="h-6 w-6 shrink-0 text-brand-500 transition-transform group-hover:scale-105 sm:h-7 sm:w-7"
      />

      <span className="font-display text-xl font-extrabold tracking-tight sm:text-2xl">
        <span className={dark ? "text-white" : "text-ink"}>
          Season
        </span>
        <span className="text-brand-500">
          {" "}Marketing
        </span>
      </span>
    </Link>
  );
}
