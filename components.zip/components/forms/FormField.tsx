// The shared form pieces moved to components/forms/FormField.tsx.
// This file keeps the old import path working for the auth forms.
export { default, inputClass, textareaClass, primaryBtn, secondaryBtn, describedBy, DemoNotice } from "@/components/forms/FormField";