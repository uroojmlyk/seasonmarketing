import { Suspense } from "react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Chatbot from "@/components/ui/Chatbot";

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      {/* Suspense wrap taake usePathname ka prerender error khatam ho */}
      <Suspense fallback={<div className="h-24 bg-ink" />}>
        <Navbar />
      </Suspense>
      
      <main>{children}</main>
      
      <Footer />
      <Chatbot />
    </>
  );
}