import { Suspense } from "react";
import { notFound } from "next/navigation";
import PropertyDetailClient from "@/features/properties/components/PropertyDetailClient";
import { allProperties } from "@/lib/constants/data";

async function PropertyContent({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const property = allProperties.find((p) => p.slug === slug);

  if (!property) notFound();

  const similarProperties = allProperties
    .filter(p => p.slug !== property.slug && p.city === property.city)
    .slice(0, 3);

  return <PropertyDetailClient property={property} similarProperties={similarProperties} />;
}

export default function PropertyDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  return (
    <Suspense fallback={
      <div className="flex min-h-screen items-center justify-center bg-neutral-50">
        <p className="text-sm font-medium text-neutral-500">Loading property details...</p>
      </div>
    }>
      <PropertyContent params={params} />
    </Suspense>
  );
}